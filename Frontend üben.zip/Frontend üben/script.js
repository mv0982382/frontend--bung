function createBox(titleText) {
  const box = document.createElement("div");
  box.className = "box";

  const heading = document.createElement("h3");
  heading.textContent = titleText;

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "polygon");
  svg.setAttribute("viewBox", "0 0 54 48");
  svg.setAttribute("fill", "none");
  svg.innerHTML = `
    <path d="M27 0.5L53.4138 47.75H0.586226L27 0.5Z" fill="#D9D9D9" />
  `;

  const button = document.createElement("button");
  button.className = "box-button";
  button.textContent = "Bestätigen";

  box.appendChild(heading);
  box.appendChild(svg);
  box.appendChild(button);

  return box;
}

const boxesContainer = document.querySelector(".boxes");
for (let i = 1; i <= 40; i++) {
  boxesContainer.appendChild(createBox(`Text Box ${i}`));
}
